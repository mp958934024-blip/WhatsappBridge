const express = require('express');
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode');

const app = express();
app.use(express.json());

let qrCodeData = null;
let clientStatus = "Connecting...";
let isReady = false;

const client = new Client({
    authStrategy: new LocalAuth(),
    puppeteer: { headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }
});

client.on('qr', async (qr) => {
    console.log('QR RECEIVED');
    qrCodeData = await qrcode.toDataURL(qr);
    clientStatus = "QR Ready - Scan Karo";
});

client.on('ready', () => {
    console.log('Client is ready!');
    isReady = true;
    clientStatus = "Connected";
    qrCodeData = null;
});

client.on('disconnected', () => {
    isReady = false;
    clientStatus = "Disconnected";
});

app.get('/connect', (req, res) => {
    if (isReady) {
        return res.send('<html><body style="text-align:center;font-family:sans-serif;"><h1>WhatsApp Connected Hai!</h1></body></html>');
    }
    if (qrCodeData) {
        return res.send(`<html><body style="text-align:center;font-family:sans-serif;"><h1>WhatsApp Scan Karo</h1><img src="${qrCodeData}" width="400" height="400"/><p>Page auto refresh hoga</p><script>setTimeout(()=>location.reload(), 20000);</script></body></html>`);
    }
    res.send(`<html><body style="text-align:center;font-family:sans-serif;"><h1>${clientStatus}</h1><p>Wait karo...</p><script>setTimeout(()=>location.reload(), 3000);</script></body></html>`);
});

app.get('/status', (req, res) => {
    res.json({ status: clientStatus, ready: isReady });
});

app.post('/send', async (req, res) => {
    const { number, message } = req.body;
    if (!isReady) return res.status(400).json({ error: 'WhatsApp connected nahi hai' });
    try {
        const chatId = number.includes('@c.us') ? number : `${number}@c.us`;
        await client.sendMessage(chatId, message);
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

client.initialize();

app.listen(3001, () => {
    console.log('Bridge Running on 3001');
});